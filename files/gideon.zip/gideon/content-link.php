<article class="post post-link">
    <a href=" <?php get_the_content(); ?> "> <?php the_title(); ?></a>
</article>