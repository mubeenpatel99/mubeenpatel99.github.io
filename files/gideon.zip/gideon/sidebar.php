<div class="secondary-column">
    <?php dynamic_sidebar('sidebar1'); ?>
    <?php dynamic_sidebar('sidebar2'); ?>
</div>